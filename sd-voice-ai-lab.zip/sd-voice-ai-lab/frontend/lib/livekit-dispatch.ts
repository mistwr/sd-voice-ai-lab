import { AgentDispatchClient, RoomServiceClient } from "livekit-server-sdk";

// Só correr no servidor (Route Handlers). As chaves LIVEKIT_API_KEY /
// LIVEKIT_API_SECRET nunca devem chegar ao browser.
const livekitUrl = process.env.LIVEKIT_URL!;
const apiKey = process.env.LIVEKIT_API_KEY!;
const apiSecret = process.env.LIVEKIT_API_SECRET!;

export interface DialInfo {
  call_id: string;
  company_id: string;
  phone_number: string;
  agent_name: string;
  objective: string;
  script: string;
  transfer_to?: string | null;
  recording_enabled: boolean;
}

/**
 * Cria uma nova room e despacha o worker "sd-voice-outbound" com a
 * metadata da chamada. O worker (worker/agent.py) é responsável por
 * marcar o participante SIP real.
 */
export async function dispatchOutboundCall(dial: DialInfo) {
  const httpUrl = livekitUrl.replace("wss://", "https://").replace("ws://", "http://");

  const dispatchClient = new AgentDispatchClient(httpUrl, apiKey, apiSecret);
  const roomClient = new RoomServiceClient(httpUrl, apiKey, apiSecret);

  const roomName = `sd-voice-${dial.call_id}`;

  await roomClient.createRoom({ name: roomName });

  const dispatch = await dispatchClient.createDispatch(roomName, "sd-voice-outbound", {
    metadata: JSON.stringify(dial),
  });

  return { roomName, dispatchId: dispatch.id };
}
