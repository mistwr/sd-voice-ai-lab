import { createClient } from "@supabase/supabase-js";

// Cliente client-side com a ANON KEY pública — as políticas RLS (ver
// supabase/schema.sql) garantem que cada utilizador só vê os dados da
// sua própria empresa.
export function getSupabaseBrowserClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
