import { createClient } from "@supabase/supabase-js";

// Cliente server-side com SERVICE ROLE KEY.
// Usar APENAS dentro de app/api/**/route.ts (Route Handlers correm no
// servidor). NUNCA importar este ficheiro num componente "use client".
export function getSupabaseServerClient() {
  const url = process.env.SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !serviceRoleKey) {
    throw new Error("SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY em falta no ambiente do servidor.");
  }

  return createClient(url, serviceRoleKey, {
    auth: { persistSession: false },
  });
}
